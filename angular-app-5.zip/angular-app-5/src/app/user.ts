export interface User {
    name: string,
    email: string,
    contact: string,
    address: string,
    city: string,
    state: string,
    zip: string,
    check: boolean
}