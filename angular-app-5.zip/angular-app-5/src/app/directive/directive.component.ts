import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directive',
  templateUrl: './directive.component.html',
  styleUrls: ['./directive.component.css']
})
export class DirectiveComponent implements OnInit {
  title = "GOT Charachters";
  GOTCharachter = [];
  GOTCharachterFullName = ['John Snow', 'Arya Stark', 'Tyrion Lannister', 'Daenerys Tragaryen', 'Khal Drogo'];
  GOTCharachterLastName = ['Snow', 'Stark', 'Lannister', 'Tragaryen', 'Drogo'];
  i = 0;
  ind = 0;
  stopSwitch;
  stopSwitchStatus = true;
  toggleFlag = true;
  selectedCharachter;

  mystyle = {};
  color;

  currentCss = 'table table-sm table-striped';

  toggleCss() {
    if (this.currentCss == 'table table-sm table-striped') {
      this.currentCss = 'table table-sm table-striped table-dark';
    }
    else {
      this.currentCss = 'table table-sm table-striped';
    }
    console.log(this.currentCss);
  }

  setStyle() {
    this.mystyle = {
      'font-weight': 'bold',
      'color': this.randomColor()
    }
  }

  randomColor() {
    this.color = '#'
    var letters = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'];
    for (var i = 0; i < 6; i++) {
      this.color += letters[Math.floor(Math.random() * 16)];
    }
    console.log(this.color);
    return this.color;
  }

  selectCharachter(charachter) {
    this.selectedCharachter = charachter;
  }

  toggle() {
    this.toggleFlag = !this.toggleFlag;
  }

  stopSwitchFirstnLastName() {
    clearInterval(this.stopSwitch);
    this.stopSwitchStatus = true;
  }

  switchFirstnLastName() {
    this.stopSwitch = setInterval(() => {
      if (this.i % 2 == 0) {
        this.GOTCharachter = this.GOTCharachterFullName;
        console.log('if');
      } else {
        this.GOTCharachter = this.GOTCharachterLastName;
        console.log('else');
      }
      this.i++;
    }, 2000);
    this.stopSwitchStatus = false;
  }

  constructor() {

  }

  ngOnInit() {
  }

}
