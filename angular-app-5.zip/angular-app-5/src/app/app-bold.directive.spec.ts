import { AppBoldDirective } from './app-bold.directive';

describe('AppBoldDirective', () => {
  it('should create an instance', () => {
    const directive = new AppBoldDirective();
    expect(directive).toBeTruthy();
  });
});
