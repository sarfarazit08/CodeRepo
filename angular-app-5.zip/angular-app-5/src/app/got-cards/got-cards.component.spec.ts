import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GotCardsComponent } from './got-cards.component';

describe('GotCardsComponent', () => {
  let component: GotCardsComponent;
  let fixture: ComponentFixture<GotCardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GotCardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GotCardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
