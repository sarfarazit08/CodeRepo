import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router'

@Component({
  selector: 'app-got-cards',
  templateUrl: './got-cards.component.html',
  styleUrls: ['./got-cards.component.css']
})
export class GotCardsComponent implements OnInit {

  imgurl = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRfmdAWnlvimN_BnxOk603E7Ghr1NuTYS-hv7xhueApYPG4c3HxFDYt_iUk';

  constructor(private router : Router) { }

  redirectToCards() {
    this.router.navigate(['/cards']);
  }

  ngOnInit() {
  }

} 
