import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { AboutComponent } from './about/about.component';
import { CardsComponent } from './cards/cards.component';
import { FooterComponent } from './footer/footer.component';
import { DirectiveComponent } from './directive/directive.component';
import { HomeComponent } from './home/home.component';
import { AppBoldDirective } from './app-bold.directive';
import { GotCardsComponent } from './got-cards/got-cards.component';
import { TemplateFormComponent } from './template-form/template-form.component';
import { UserComponent } from './user/user.component';


const ROUTES = [
  { path: '', component: HomeComponent },
  { path: 'about', component: AboutComponent },
  { path: 'directive', component: DirectiveComponent },
  { path: 'cards', component: CardsComponent },
  { path: 'gotcards', component: GotCardsComponent },
  { path: 'templateform', component: TemplateFormComponent },
  { path: 'user', component: UserComponent },
]

@NgModule({
  declarations: [
    AppComponent, HomeComponent, AboutComponent, CardsComponent, FooterComponent, DirectiveComponent,
    AppBoldDirective, GotCardsComponent, TemplateFormComponent, UserComponent,
  ],
  imports: [
    BrowserModule, FormsModule, RouterModule.forRoot(ROUTES)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
